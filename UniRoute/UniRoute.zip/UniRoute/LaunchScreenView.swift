//
//  LaunchScreenView.swift
//  UniRoute
//
//  Created by Sherren Jie on 10/12/24.
//
import SwiftUI
import UIKit

struct LaunchScreenView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> LaunchViewController {
        return LaunchViewController()
    }
    
    func updateUIViewController(_ uiViewController: LaunchViewController, context: Context) {
        
    }
}

